"""ClaudeTrade test suite."""
